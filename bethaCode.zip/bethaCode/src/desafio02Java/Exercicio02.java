package desafio02Java;
/*Escreva um laço while que execute 20 vezes, imprimindo o valor da variável x que inicialmente está com valor 10. */
public class Exercicio02 {
    public static void main(String[]args){
        int x = 10 ;
        while(x <= 30) {
            System.out.println("item" + x);
            x++;
        }
    }
}
