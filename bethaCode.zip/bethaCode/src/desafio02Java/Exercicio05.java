package desafio02Java;

public class Exercicio05 {
    public static void main(String [] args){
     double h = 1.5 ; //altura
     double b = 0.5 ; //base menor
     double B = 0.75 ;//base maior
     double area = (h*(b+B))/2;
    System.out.println("A área do trapézio é  =  " + area);
    }
}
