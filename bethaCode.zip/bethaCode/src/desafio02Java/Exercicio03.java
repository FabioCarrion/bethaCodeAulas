package desafio02Java;
/*Converta este laço do exercício anterior para um do-while.*/
public class Exercicio03 {
    public static void main(String[]args){
        int x = 10 ;
        do {
            System.out.println("item" + x);
            x++;
        } while (x <= 30);

    }
}




