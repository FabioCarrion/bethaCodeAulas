public class ControleFluxoForMain {
    public static void main(String[]args){
        for (int x = 4; x > 0 ;x--){
           System.out.println("item" +x);
        }
    }

}
