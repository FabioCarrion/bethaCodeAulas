public class ControleFluxoSwitchCaseMain {
    public static void main(String [] args) {
        char  letra  = 'A' ;

        switch (letra) {
            case 'A' :
                System.out.println("A");
                break;
            case 'B' :
                System.out.println("B");
                break;
            default:
                System.out.println("?");
        }


    }

}
