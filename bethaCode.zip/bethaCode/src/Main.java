public class Main {
    public static void main (String[] parametros) {
        System.out.println("Curso Java Iniciante !!");
    }
}
