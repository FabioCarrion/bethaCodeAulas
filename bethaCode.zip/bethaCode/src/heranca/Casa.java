package heranca;

public class Casa extends Construcao{
    public Casa(Integer numeroQuartos, Integer numeroBanheiros, Double metragem) {
        super(numeroQuartos, numeroBanheiros, metragem);
    }


}
