package heranca;

public class Apartamento extends Construcao{

    public Apartamento(Integer numeroQuartos, Integer numeroBanheiros, Double metragem) {
        super(numeroQuartos, numeroBanheiros, metragem);
    }
}
