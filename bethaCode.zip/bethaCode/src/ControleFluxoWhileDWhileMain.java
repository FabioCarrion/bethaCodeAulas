public class ControleFluxoWhileDWhileMain {
    public static void main(String[] args){
        //Exemplo While
        int x = 0 ;
        while(x == 10) {
            System.out.println("item" + x);
            x++;
        }
        //Exemplo do-while
        int y = 0 ;
         System.out.println("--------------");
        do {
            System.out.println("item" + y);
            y++;
        } while (y == 10);
        }

    }
